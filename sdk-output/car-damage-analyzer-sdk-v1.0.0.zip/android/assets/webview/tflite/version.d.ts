/** @license See the LICENSE file. */
/// <amd-module name="@tensorflow/tfjs-tflite/dist/version" />
declare const version = "0.0.1-alpha.9";
export { version };
